//
//  ProfileTableViewCell.m
//  Divine2Logic
//
//  Created by Apple on 12/02/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import "ProfileTableViewCell.h"

@implementation ProfileTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
