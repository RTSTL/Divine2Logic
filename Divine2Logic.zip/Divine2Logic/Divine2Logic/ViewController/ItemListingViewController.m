//
//  ItemListingViewController.m
//  Divine2Logic
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import "ItemListingViewController.h"

@interface ItemListingViewController ()

@end

@implementation ItemListingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self performRequestForItem];
    itemTbl.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- API Integration

-(void)performRequestForItem
{
    if([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == NotReachable)
    {
        [MMCommon showOnlyAlert:@"Sorry!" :@"Check Your Internet Connection.":self.navigationController];
    }
    else{
        [[MMCommon sharedInstance] showfullScreenIndicator:YES animated:YES];
        
        NSString *requestStr = @"Item/GetSearchItemlist";
        
        ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL,requestStr]]];
        
        request.delegate=self;
        [request setUseSessionPersistence:NO];
        
        [request addPostValue:_dispItemId forKey:@"itm_subtype_id"];
        
        [request startAsynchronous];
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSLog(@"%@",request.responseString);
    
    itemJson = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingAllowFragments error:nil];
    
    if ([[itemJson valueForKey:@"status"] intValue] == 1)
    {
        [[MMCommon sharedInstance] showfullScreenIndicator:NO animated:YES];
        
        itemArray = [[NSMutableArray alloc]init];
        itemArray = [itemJson objectForKey:@"list"];
        
        [itemTbl reloadData];
    }
    else
    {
        [[MMCommon sharedInstance] showfullScreenIndicator:NO animated:YES];
        [MMCommon showOnlyAlert:@"Sorry!" :[itemJson valueForKey:@"msg"]:self.navigationController];
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    [[MMCommon sharedInstance] showfullScreenIndicator:NO animated:YES];
    [MMCommon showOnlyAlert:@"Sorry!" :@"Something Went Wrong.":self.navigationController];
}

#pragma mark-Table Implementation

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    return [itemArray count];
}

-(ItemTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier=@"ItemListing";
    
    ItemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier ];
    
    if (cell == nil) {
        cell = [[ItemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSString *imageURL = [NSString stringWithFormat:@"%@%@",IMAGE_BASE_URL,[[itemArray objectAtIndex:indexPath.row] valueForKey:@"pic_url1"]];
    [cell.itemImage sd_setImageWithURL:[NSURL URLWithString:imageURL]];
    
    cell.itemName.text = [[itemArray objectAtIndex:indexPath.row] valueForKey:@"itm_name"];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //        NSLog(@"Clicked Id: %@", [[subCatArray objectAtIndex:indexPath.row] valueForKey:@"item_subtype_id"]);
        ItemDetailsViewController  *itemDetailsVC = (ItemDetailsViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"ItemDetailsViewController"];
        itemDetailsVC.productId = [[itemArray objectAtIndex:indexPath.row] valueForKey:@"itm_id"];
        [self.navigationController pushViewController:itemDetailsVC animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)backCallBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
@end
