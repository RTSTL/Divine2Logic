//
//  ChildOfSubCatViewController.m
//  Divine2Logic
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import "ChildOfSubCatViewController.h"

@interface ChildOfSubCatViewController ()

@end

@implementation ChildOfSubCatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    childSubLbl.text = _subItem;
    
    [self performRequestForChildSubCatagory];
    childSubCatTbl.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- API Integration

-(void)performRequestForChildSubCatagory
{
    if([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == NotReachable)
    {
        [MMCommon showOnlyAlert:@"Sorry!" :@"Check Your Internet Connection.":self.navigationController];
    }
    else{
        [[MMCommon sharedInstance] showfullScreenIndicator:YES animated:YES];
        
        NSString *requestStr = @"MSItemSubType/GetMSItemSubTypeByPrID";
        
        ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASE_URL,requestStr]]];
        
        request.delegate=self;
        [request setUseSessionPersistence:NO];
        
        [request addPostValue:_subItemId forKey:@"pr_itm_subtype_id"];
        
        [request startAsynchronous];
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSLog(@"%@",request.responseString);
    
    childSubCatJson = [NSJSONSerialization JSONObjectWithData:request.responseData options:NSJSONReadingAllowFragments error:nil];
    
    if ([[childSubCatJson valueForKey:@"status"] intValue] == 1)
    {
        [[MMCommon sharedInstance] showfullScreenIndicator:NO animated:YES];
        
        childSubCatArray = [[NSMutableArray alloc]init];
        childSubCatArray = [childSubCatJson objectForKey:@"list"];
        
        [childSubCatTbl reloadData];
    }
    else
    {
        [[MMCommon sharedInstance] showfullScreenIndicator:NO animated:YES];
        [MMCommon showOnlyAlert:@"Sorry!" :[childSubCatJson valueForKey:@"msg"]:self.navigationController];
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    [[MMCommon sharedInstance] showfullScreenIndicator:NO animated:YES];
    [MMCommon showOnlyAlert:@"Sorry!" :@"Something Went Wrong.":self.navigationController];
}

#pragma mark-Table Implementation

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    return [childSubCatArray count];
}

-(CategoryListingTableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier=@"ChildSubCategoryListing"; 
    
    CategoryListingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier ];
    
    if (cell == nil) {
        cell = [[CategoryListingTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSString *prependStr = [NSString stringWithFormat:@"data:image/png;base64,%@",[[childSubCatArray objectAtIndex:indexPath.row] valueForKey:@"pic_content"]];
    NSURL *url = [NSURL URLWithString:prependStr];
    NSData *imageData = [NSData dataWithContentsOfURL:url];
    UIImage *ret = [UIImage imageWithData:imageData];
    
    cell.categoryImageView.image = ret;
    cell.categoryTitle.text = [[childSubCatArray objectAtIndex:indexPath.row] valueForKey:@"item_subtype_nm"];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
            NSLog(@"Clicked Id: %@", [[childSubCatArray objectAtIndex:indexPath.row] valueForKey:@"item_subtype_id"]);
    ItemListingViewController  *itemVC = (ItemListingViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"ItemListingViewController"];
    itemVC.dispItemId = [[childSubCatArray objectAtIndex:indexPath.row] valueForKey:@"item_subtype_id"];
    itemVC.dispItem = [[childSubCatArray objectAtIndex:indexPath.row] valueForKey:@"item_subtype_nm"];
    [self.navigationController pushViewController:itemVC animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)backCallBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
