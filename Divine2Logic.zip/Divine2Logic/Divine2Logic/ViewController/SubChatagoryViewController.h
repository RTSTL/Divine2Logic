//
//  SubChatagoryViewController.h
//  Divine2Logic
//
//  Created by Apple on 11/04/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMCommon.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"
#import "CategoryListingTableViewCell.h"
#import "ChildOfSubCatViewController.h"

@interface SubChatagoryViewController : UIViewController
{
    NSDictionary *subCatJson;
    NSMutableArray *subCatArray;
    
    IBOutlet UILabel *titleLbl;
    IBOutlet UITableView *subCatTbl;
}

@property (strong, nonatomic) IBOutlet NSString *item, *itemId;

@end
