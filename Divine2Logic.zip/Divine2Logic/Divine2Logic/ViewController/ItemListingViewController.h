//
//  ItemListingViewController.h
//  Divine2Logic
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMCommon.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"
#import "ItemTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "ItemDetailsViewController.h"

@interface ItemListingViewController : UIViewController
{
    NSDictionary *itemJson;
    NSMutableArray *itemArray;
    
    IBOutlet UILabel *titleLbl;
    IBOutlet UITableView *itemTbl;
}

@property (strong, nonatomic) IBOutlet NSString *dispItem, *dispItemId;

@end
