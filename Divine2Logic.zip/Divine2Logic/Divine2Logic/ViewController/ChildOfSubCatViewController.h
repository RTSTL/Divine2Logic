//
//  ChildOfSubCatViewController.h
//  Divine2Logic
//
//  Created by Apple on 12/04/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMCommon.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"
#import "CategoryListingTableViewCell.h"
#import "ItemListingViewController.h"

@interface ChildOfSubCatViewController : UIViewController
{
    NSDictionary *childSubCatJson;
    NSMutableArray *childSubCatArray;
    
    IBOutlet UITableView *childSubCatTbl;
    IBOutlet UILabel *childSubLbl;
}

@property (strong, nonatomic) IBOutlet NSString *subItem, *subItemId;
@end
