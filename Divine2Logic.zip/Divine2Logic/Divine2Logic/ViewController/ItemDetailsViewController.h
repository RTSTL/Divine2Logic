//
//  ItemDetailsViewController.h
//  Divine2Logic
//
//  Created by Apple on 13/04/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMCommon.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"

@interface ItemDetailsViewController : UIViewController
{
    NSDictionary *productJson;
}
@property (strong, nonatomic) IBOutlet NSString *productId;
@end
