//
//  CategoryListingTableViewCell.m
//  Divine2Logic
//
//  Created by Apple on 20/02/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import "CategoryListingTableViewCell.h"

@implementation CategoryListingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
