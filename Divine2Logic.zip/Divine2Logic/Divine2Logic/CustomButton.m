//
//  CustomButton.m
//  Divine2Logic
//
//  Created by Apple on 23/02/18.
//  Copyright © 2018 Rtstl. All rights reserved.
//

#import "CustomButton.h"

@implementation CustomButton

@synthesize optionData;
@synthesize fieldValue;
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
